import customtkinter as ctk
import time

class LoadingScreen(ctk.CTk):
    def __init__(self):
        super().__init__()

        self.title("🚀 Загрузка...")
        self.geometry("400x300")
        self.resizable(False, False)
        ctk.set_appearance_mode("dark")
        ctk.set_default_color_theme("blue")

        self.label = ctk.CTkLabel(self, text="Инициализация компонентов...", font=("Poppins", 20))
        self.label.pack(pady=50)

        self.progress = ctk.CTkProgressBar(self, width=300)
        self.progress.pack(pady=20)
        self.progress.set(0)

    def start(self):
        for i in range(101):
            time.sleep(0.02)
            self.progress.set(i/100)
            self.update_idletasks()

        self.destroy()
