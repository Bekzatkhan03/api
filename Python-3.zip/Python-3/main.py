import customtkinter as ctk
import threading
import time
import os
import json
from datetime import datetime
import matplotlib.pyplot as plt
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
from order_logic import process_orders, read_orders  


ctk.set_appearance_mode("dark")
ctk.set_default_color_theme("dark-blue")

ORDERS_JSON = "orders.json"

class OrderApp(ctk.CTk):
    def __init__(self):
        super().__init__()
        self.title("Order Manager with Sell Orders")
        self.geometry("1200x800")
        self.resizable(False, False)

        self.orders = []

        self.create_widgets()

    def create_widgets(self):

        self.label = ctk.CTkLabel(self, text="Order Management Panel (BUY → SELL)", font=("Poppins", 24, "bold"))
        self.label.pack(pady=20)


        self.refresh_btn = ctk.CTkButton(
            self,
            text="Refresh & Process Orders",
            command=self.refresh_orders,
            width=250,
            height=50,
            font=("Poppins", 16)
        )
        self.refresh_btn.pack(pady=10)

        self.table = ctk.CTkTextbox(self, width=1100, height=300, font=("Consolas", 14))
        self.table.pack(pady=20)

        self.figure, self.ax = plt.subplots(figsize=(9, 4), dpi=100)
        self.canvas = FigureCanvasTkAgg(self.figure, master=self)
        self.canvas.get_tk_widget().pack(pady=10)

        self.status_label = ctk.CTkLabel(self, text="", font=("Poppins", 16))
        self.status_label.pack(pady=10)

    def refresh_orders(self):
        self.status_label.configure(text="Processing...")
        self.table.delete("0.0", "end")

        def task():
            process_orders()
            self.orders = read_orders()

            for ord in self.orders:
                buy_price = ord.get('price', 0)
                sell_id = ord.get('sell_order', '-')
                line = f"{ord['id'][:8]} | {ord['symbol']} | Buy: {buy_price} | Sell ID: {sell_id} | {ord['status']} | {ord.get('checked_at', '-')}\n"
                self.table.insert("end", line)

            self.update_chart()
            self.status_label.configure(text=f"Orders Loaded: {len(self.orders)}")

        threading.Thread(target=task, daemon=True).start()

    def update_chart(self):
        self.ax.clear()
        buy_prices = [order.get('price', 0) for order in self.orders]
        sell_prices = [round(order['price'] * 1.02, 3) for order in self.orders if order.get('sell_order')]

        if buy_prices:
            self.ax.plot(buy_prices, label="Buy Prices", marker="o")
        if sell_prices:
            self.ax.plot(sell_prices, label="Projected Sell Prices", marker="x")

        self.ax.set_title("Buy vs Sell Prices", color="white")
        self.ax.set_facecolor("#222222")
        self.figure.patch.set_facecolor('#222222')
        self.ax.tick_params(axis='x', colors='white')
        self.ax.tick_params(axis='y', colors='white')
        self.ax.legend()
        self.canvas.draw()

if __name__ == "__main__":
    app = OrderApp()
    app.mainloop()
