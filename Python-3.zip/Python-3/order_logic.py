import requests
import json
import time
from datetime import datetime
import math

# Константы
API_KEY = ""
API_URL = "https://api.ataix.kz"
ORDERS_JSON = "orders.json"

HEADERS = {
    "X-API-Key": API_KEY,
    "Content-Type": "application/json"
}

# --- Вспомогательные функции ---

def smart_round(val, step=0.001):
    """Округляет значение до ближайшего шага."""
    precision = int(-1 * round(math.log10(step)))
    return round(round(val / step) * step, precision)

def read_orders():
    """Чтение ордеров из локального файла."""
    try:
        with open(ORDERS_JSON, "r", encoding="utf-8") as file:
            return json.load(file)
    except Exception:
        print("❌ Не удалось прочитать файл orders.json")
        return []

def write_orders(data):
    """Сохранение ордеров в локальный файл."""
    with open(ORDERS_JSON, "w", encoding="utf-8") as file:
        json.dump(data, file, indent=4, ensure_ascii=False)

def get_status(order_id):
    """Получение текущего статуса ордера."""
    try:
        res = requests.get(f"{API_URL}/api/orders/{order_id}", headers=HEADERS)
        res_json = res.json()
        return res_json.get("result", {}).get("status", "").lower()
    except Exception:
        return "unknown"

def submit_sell(symbol, price, qty):
    """Создание нового Sell-ордера."""
    payload = {
        "symbol": symbol,
        "side": "sell",
        "type": "limit",
        "price": round(price, 6),
        "quantity": round(qty, 8)
    }
    try:
        res = requests.post(f"{API_URL}/api/orders", headers=HEADERS, json=payload)
        result = res.json()
        if result.get("status"):
            return result.get("result", {}).get("orderID", "unknown")
        return None
    except Exception as e:
        print(f"❌ Ошибка при создании Sell-ордера: {e}")
        return None

# --- Основная обработка ордеров ---

def process_orders():
    """Обновляет ордера: проверяет статусы и создает Sell-ордера при исполнении Buy."""
    orders = read_orders()
    updated_orders = []

    for entry in orders:
        try:
            oid = entry.get("id", "undefined")
            current_status = get_status(oid)
            time.sleep(0.4)  # Небольшая задержка для избежания спама на API

            log_time = datetime.now().strftime('%Y-%m-%d %H:%M:%S')

            if current_status == "filled" and "sell_order" not in entry:
                print(f"[{log_time}] ✅ Ордер {oid} исполнен. Генерация SELL...")
                new_sell_price = round(entry["price"] * 1.02, 3)
                sell_id = submit_sell(entry["symbol"], new_sell_price, entry["amount"])

                if sell_id:
                    entry["sell_order"] = sell_id
                    print(f"🆕 Sell-ордер создан: {sell_id}")
                else:
                    print(f"❌ Не удалось создать sell-ордер для {oid}")

            elif current_status == "new":
                print(f"[{log_time}] ⏳ Ордер {oid} в ожидании исполнения.")
            elif current_status == "cancelled":
                print(f"[{log_time}] 🛑 Ордер {oid} был отменён.")
            elif current_status == "unknown":
                print(f"[{log_time}] ⚠️ Статус ордера {oid} не удалось определить.")
            else:
                print(f"[{log_time}] ℹ️ Ордер {oid} — статус: {current_status}")

            entry["status"] = current_status
            entry["checked_at"] = log_time
            updated_orders.append(entry)

        except Exception as e:
            print(f"⚠️ Ошибка обработки ордера {entry.get('id', 'unknown')}: {e}")

    write_orders(updated_orders)
    print("\n📁 Обновление завершено. Все данные записаны в orders.json")
