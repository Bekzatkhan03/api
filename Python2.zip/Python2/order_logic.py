import requests
import json
import time
from datetime import datetime

API_KEY = "w0iwBGK1axMcwxB6D1S5dnFPaIXR9pvXnek7HHQPxfsR0aAX6c1dIsge9JDh1KkBKdDThVcAtYmoEZphzNEJGV"
BASE = "https://api.ataix.kz"
HEADERS = {
    "X-API-Key": API_KEY,
    "Content-Type": "application/json"
}
FILE_NAME = "orders.json"

def load_orders():
    try:
        with open(FILE_NAME, "r", encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return []

def save_orders(orders):
    with open(FILE_NAME, "w", encoding="utf-8") as f:
        json.dump(orders, f, indent=4, ensure_ascii=False)

def fetch_status(order_id):
    try:
        res = requests.get(f"{BASE}/api/orders/{order_id}", headers=HEADERS)
        result = res.json()
        return result.get("result", {}).get("status", "unknown").lower()
    except:
        return None

def delete_order(order_id):
    try:
        res = requests.delete(f"{BASE}/api/orders/{order_id}", headers=HEADERS)
        return res.json().get("status", False)
    except:
        return False

def create_order(symbol, price, qty):
    data = {
        "symbol": symbol,
        "side": "buy",
        "type": "limit",
        "price": round(price, 6),
        "quantity": round(qty, 8)
    }
    try:
        response = requests.post(f"{BASE}/api/orders", headers=HEADERS, json=data)
        reply = response.json()
        return reply.get("result", {}).get("orderID", None)
    except:
        return None

def refresh_orders():
    orders = load_orders()
    refreshed = []

    for order in orders:
        oid = order.get("id")
        status = fetch_status(oid)
        time.sleep(0.4)

        now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

        if status == "filled":
            order["status"] = "filled"
        elif status == "new":
            if delete_order(order["id"]):
                new_price = round(order["price"] * 1.01, 3)
                new_id = create_order(order["symbol"], new_price, order["amount"])
                if new_id:
                    order = {
                        "id": new_id,
                        "symbol": order["symbol"],
                        "price": new_price,
                        "amount": order["amount"],
                        "status": "new"
                    }
                else:
                    order["status"] = "cancelled"
        elif status:
            order["status"] = status
        else:
            order["status"] = "unknown"

        order["checked_at"] = now
        refreshed.append(order)

    save_orders(refreshed)
    return refreshed
