import customtkinter as ctk
from order_logic import refresh_orders
import threading
import time
from PIL import Image
import os


ctk.set_appearance_mode("dark")
ctk.set_default_color_theme("dark-blue")  

class OrderApp(ctk.CTk):
    def __init__(self):
        super().__init__()
        self.title("Order Manager")
        self.geometry("1000x700")
        self.resizable(False, False)

        self.orders = []

        self.create_widgets()

    def create_widgets(self):

        self.label = ctk.CTkLabel(self, text="Order Management Panel", font=("Poppins", 24, "bold"))
        self.label.pack(pady=20)


        self.refresh_btn = ctk.CTkButton(
            self,
            text="Refresh Orders",
            command=self.refresh_orders,
            width=180,
            height=40,
            font=("Poppins", 16)
        )
        self.refresh_btn.pack(pady=10)


        self.table = ctk.CTkTextbox(self, width=950, height=450, font=("Consolas", 14))
        self.table.pack(pady=20)


        self.status_label = ctk.CTkLabel(self, text="", font=("Poppins", 16))
        self.status_label.pack(pady=10)

    def refresh_orders(self):
        self.status_label.configure(text="Loading...")
        self.table.delete("0.0", "end")

        def task():
            orders = refresh_orders()
            self.orders = orders

            for ord in orders:
                line = f"{ord['id'][:8]} | {ord['symbol']} | {ord['price']} | {ord['amount']} | {ord['status']} | {ord.get('checked_at', '-')}\n"
                self.table.insert("end", line)

            self.status_label.configure(text=f"Loaded: {len(orders)} orders")

        threading.Thread(target=task, daemon=True).start()

if __name__ == "__main__":
    app = OrderApp()
    app.mainloop()
